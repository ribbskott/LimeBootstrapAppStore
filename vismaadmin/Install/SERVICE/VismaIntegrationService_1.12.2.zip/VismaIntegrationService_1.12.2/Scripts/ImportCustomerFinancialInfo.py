﻿import sys
import time
import limeclient

print ('argument 0:', sys.argv[1])
client = limeclient.LimeClient('[LimeApiUri]', '[LimeApiDb]', False, False)
with client.login('[LimeApiUser]', '[LimeApiPassword]') as c:
    with open(sys.argv[1], encoding='utf-8') as content:
        f = limeclient.ImportFiles(c).create(filename='customerfinancialinfo.csv',content=content)
        f.delimiter = ';'
        f.save()
        company = limeclient.LimeTypes(c).get_by_name('company')
        config = limeclient.ImportConfigs(c).create(lime_type=company, importfile=f)
        config.behavior = limeclient.ImportConfig.OnlyUpdate

        vismaId = limeclient.SimpleFieldMapping(field=company.fields['vismaid'], column='customerid', key=True)
        config.add_mapping(vismaId)

        turnovercurrentyear = limeclient.SimpleFieldMapping(field=company.fields['visma_turnover_yearnow'], column='turnovercurrentyear', key=False)
        config.add_mapping(turnovercurrentyear)

        turnoverpreviousyear = limeclient.SimpleFieldMapping(field=company.fields['visma_turnover_lastyear'], column='turnoverpreviousyear', key=False)
        config.add_mapping(turnoverpreviousyear)

        config.save()

        job = limeclient.ImportJobs(c).create(config)
        while True:
            time.sleep(5)
            job = job.refresh()
            print('Current job status: {}'.format(job.status))
            if  job.has_errors:
                print(job.errors.errors[:10])
                break
            if job.status != 'pending' and job.status != 'running':
                break

