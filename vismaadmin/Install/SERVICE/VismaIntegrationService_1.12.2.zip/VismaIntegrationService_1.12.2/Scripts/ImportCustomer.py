﻿import sys
import time
import limeclient

print ('argument 0:', sys.argv[1])
client = limeclient.LimeClient('[LimeApiUri]', '[LimeApiDb]', False, False)
with client.login('[LimeApiUser]', '[LimeApiPassword]') as c:
    with open(sys.argv[1], encoding='utf-8') as content:
        f = limeclient.ImportFiles(c).create(filename='customers.csv',content=content)
        f.delimiter = ';'
        f.save()
        company = limeclient.LimeTypes(c).get_by_name('company')
        config = limeclient.ImportConfigs(c).create(lime_type=company, importfile=f)
        config.behavior = limeclient.ImportConfig.OnlyCreate

        vismaId = limeclient.SimpleFieldMapping(field=company.fields['vismaid'], column='customerid', key=True)
        config.add_mapping(vismaId)

        name = limeclient.SimpleFieldMapping(field=company.fields['name'], column='name', key=False)
        config.add_mapping(name)

        phone = limeclient.SimpleFieldMapping(field=company.fields['phone'], column='telephone', key=False)
        config.add_mapping(phone)

        postaladdress1 = limeclient.SimpleFieldMapping(field=company.fields['postaladdress1'], column='address1', key=False)
        config.add_mapping(postaladdress1)

        postaladdress2 = limeclient.SimpleFieldMapping(field=company.fields['postaladdress2'], column='address2', key=False)
        config.add_mapping(postaladdress2)

        postalzipcode = limeclient.SimpleFieldMapping(field=company.fields['postalzipcode'], column='zipcode', key=False)
        config.add_mapping(postalzipcode)

        postalcity = limeclient.SimpleFieldMapping(field=company.fields['postalcity'], column='city', key=False)
        config.add_mapping(postalcity)

        country = limeclient.SimpleFieldMapping(field=company.fields['country'], column='country', key=False)
        config.add_mapping(country)

        visitingaddress1 = limeclient.SimpleFieldMapping(field=company.fields['visitingaddress1'], column='deliveryaddress1', key=False)
        config.add_mapping(visitingaddress1)

        visitingaddress2 = limeclient.SimpleFieldMapping(field=company.fields['visitingaddress2'], column='deliveryaddress2', key=False)
        config.add_mapping(visitingaddress2)

        visitingzipcode = limeclient.SimpleFieldMapping(field=company.fields['visitingzipcode'], column='deliveryzipcode', key=False)
        config.add_mapping(visitingzipcode)

        visitingcity = limeclient.SimpleFieldMapping(field=company.fields['visitingcity'], column='deliverycity', key=False)
        config.add_mapping(visitingcity)

        registrationno = limeclient.SimpleFieldMapping(field=company.fields['registrationno'], column='organisationnumber', key=False)
        config.add_mapping(registrationno)

        visma_turnover_yearnow = limeclient.SimpleFieldMapping(field=company.fields['visma_turnover_yearnow'], column='accumulateturnoverthisyear', key=False)
        config.add_mapping(visma_turnover_yearnow)

        visma_turnover_lastyear = limeclient.SimpleFieldMapping(field=company.fields['visma_turnover_lastyear'], column='accumulateturnoverlastyear', key=False)
        config.add_mapping(visma_turnover_lastyear)

        config.save()

        job = limeclient.ImportJobs(c).create(config)
        while True:
            time.sleep(5)
            job = job.refresh()
            print('Current job status: {}'.format(job.status))
            if  job.has_errors:
                print(job.errors.errors[:10])
                break
            if job.status != 'pending' and job.status != 'running':
                break

